import cv2
import numpy as np

def find_vanishing_point(image_path):
    # 画像を読み込み、グレースケール化
    img = cv2.imread(image_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # エッジ検出
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    
    # ハフ変換で直線検出
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 100, minLineLength=100, maxLineGap=10)
    
    if lines is None:
        print("直線が検出されませんでした。")
        return img

    # 検出した直線を描画
    for line in lines:
        x1, y1, x2, y2 = line[0]
        cv2.line(img, (x1, y1), (x2, y2), (0, 255, 0), 2)

    # 直線の交点を計算
    intersections = []
    for i in range(len(lines)):
        for j in range(i + 1, len(lines)):
            line1 = lines[i][0]
            line2 = lines[j][0]
            intersection = calculate_intersection(line1, line2)
            if intersection is not None:
                intersections.append(intersection)

    if len(intersections) == 0:
        print("交点が見つかりませんでした。")
        return img

    # 消失点を推定（交点の重心を取る）
    vanishing_point = np.mean(intersections, axis=0).astype(int)
    cv2.circle(img, tuple(vanishing_point), 10, (0, 0, 255), -1)
    print(vanishing_point)

    return img

def calculate_intersection(line1, line2):
    x1, y1, x2, y2 = line1
    x3, y3, x4, y4 = line2

    denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if denom == 0:
        return None

    px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / denom
    py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / denom

    return [px, py]

def calculate_scale(image_path, real_distance, reference_points):
    """
    消失点と基準オブジェクトを使用して縮尺を計算する関数。

    :param image_path: 画像のパス
    :param real_distance: 基準オブジェクトの実際の距離（メートル）
    :param reference_points: 基準オブジェクトの2つの点の座標 [(x1, y1), (x2, y2)]
    :return: 画像内のピクセルあたりの実際の距離（メートル/ピクセル）
    """
    # 画像の読み込み
    img = cv2.imread(image_path)

    # 基準オブジェクトのピクセル距離を計算
    (x1, y1), (x2, y2) = reference_points
    pixel_distance = np.sqrt((x2 - x1)**2 + (y2 - y1)**2)

    # 実際の距離とピクセル距離の比率を計算
    scale = real_distance / pixel_distance
    return scale

# 実行
output_image = find_vanishing_point('test2.jpg')
cv2.imshow('Vanishing Point', output_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# calculate_scale('test2.jpg', 2, )