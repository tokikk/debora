import cv2
import numpy as np
from sklearn.cluster import DBSCAN

# https://zenn.dev/mattyamonaca/articles/48f0034e928018

def find_vanishing_point(img):
   
    # グレースケールにして明暗の境界(=エッジ)を検出する
    # つまり物体の境界線を取得？
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    auto_contrast = cv2.equalizeHist(blurred)
    edges = cv2.Canny(auto_contrast, 50, 150, apertureSize=3)
    
    # ハフ変換(=多数決により直線を検出する)で直線検出
    # https://qiita.com/Mas-sensyn/items/d957ad5984278a70faa8
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 100, minLineLength=100, maxLineGap=10)
   
    # 角度によるフィルタリング
    # ほぼ水平に近い角度の直線は通常採用されるべきでない
    lines = filter_lines_by_angle(lines)

    # 中心からの距離でフィルタリング
    # 画像中心から大きく外れる場合は採用されるべきではない
    # 通常、消失点は画像の中央付近に位置すると仮定される
    #lines = filter_lines_by_distance_to_center(lines, img.shape)

    # 収束性の評価によるフィルタリング
    # 交点の分布が一定の閾値を超えない場合のみ消失点の検出を行う
    # 閾値を超えた場合の戻り値はブランクリスト
    #lines = filter_lines_by_convergence(lines)

    print(lines)
    if lines is None:
        print("直線が検出されませんでした。")
        return img
    elif len(lines) == 0:
        print("直線が検出されませんでした。")
        return img
    else:
        # 検出した直線を描画
        for line in lines:
            x1, y1, x2, y2 = line[0]
            cv2.line(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
    
    # すべての直線のペアの交点を計算
    intersections = []
    for i in range(len(lines)):
        for j in range(i + 1, len(lines)):
            line1 = extend_line(lines[i][0], img.shape)
            line2 = extend_line(lines[j][0], img.shape)
            intersection = calculate_intersection(line1, line2)
            if intersection is not None:
                intersections.append(intersection)
    
    if len(intersections) == 0:
        print("交点が見つかりませんでした。")
        return img, None
    
    # DBSCANでクラスタリング
    intersections = np.array(intersections)
    clustering = DBSCAN(eps=0.01, min_samples=2).fit(intersections)

    # クラスタのラベルを取得
    labels = clustering.labels_

    # 最大クラスタ（-1はノイズとして無視）
    unique_labels, counts = np.unique(labels[labels != -1], return_counts=True)
    if len(unique_labels) == 0:
        print("有効なクラスタが見つかりませんでした。")
        return img, None

    main_cluster_label = unique_labels[np.argmax(counts)]
    main_cluster_points = intersections[labels == main_cluster_label]
  
    # 消失点を推定（交点の重心を取る）
    vanishing_point = np.mean(main_cluster_points, axis=0).astype(int)
    print(f"消失点の座標 >> {vanishing_point}")
    cv2.circle(img, tuple(vanishing_point), 60, (255, 0, 0), -1)


    return img

def filter_lines_by_angle(lines, angle_range=(5, 85), exclude_near_vertical=True, vertical_threshold=(85, 95)):
    """
    指定された角度範囲内の直線をフィルタリングし、必要に応じて垂直に近い直線も除外する。

    :param lines: ハフ変換で検出された直線のリスト [(x1, y1, x2, y2), ...]
    :param angle_range: フィルタリングする基本角度範囲 (min_angle, max_angle)
    :param exclude_near_vertical: 垂直に近い直線を除外するかどうか
    :param vertical_threshold: 垂直に近い直線を定義する角度範囲 (min_angle, max_angle)
    :return: フィルタリングされた直線のリスト
    """
    filtered_lines = []
    for line in lines:
        x1, y1, x2, y2 = line[0]

        # 直線の角度を計算
        angle = np.degrees(np.arctan2(y2 - y1, x2 - x1)) % 180

        # 垂直に近い角度の除外を考慮
        if exclude_near_vertical and vertical_threshold[0] <= angle <= vertical_threshold[1]:
            continue

        # 指定された角度範囲内であれば追加
        if angle_range[0] <= angle <= angle_range[1]:
            filtered_lines.append(line)

    return filtered_lines

def filter_lines_by_distance_to_center(lines, img_shape, max_distance=200):
    """
    画像中心からの距離に基づいて直線をフィルタリングする。
    :param lines: ハフ変換で検出された直線
    :param img_shape: 画像の形状（高さ, 幅）
    :param max_distance: 画像中心からの最大許容距離
    :return: フィルタリング後の直線
    """
    height, width = img_shape[:2]
    center = (width / 2, height / 2)
    
    filtered_lines = []
    for line in lines:
        x1, y1, x2, y2 = line[0]
        midpoint = ((x1 + x2) / 2, (y1 + y2) / 2)
        distance = np.linalg.norm(np.array(midpoint) - np.array(center))
        if distance <= max_distance:
            filtered_lines.append(line)
    return filtered_lines

def filter_lines_by_convergence(lines, threshold=50):
    """
    直線の交点の収束性を基準にフィルタリングする。
    :param lines: ハフ変換で検出された直線
    :param threshold: 交点の標準偏差の閾値
    :return: 収束性が良い直線群
    """
    intersections = []
    for i in range(len(lines)):
        for j in range(i + 1, len(lines)):
            line1 = lines[i][0]
            line2 = lines[j][0]
            intersection = calculate_intersection(line1, line2)
            if intersection is not None:
                intersections.append(intersection)

    if len(intersections) == 0:
        return []

    # 交点の分布を分析
    intersections = np.array(intersections)
    std_dev = np.std(intersections, axis=0)
    
    if np.linalg.norm(std_dev) < threshold:
        return lines  # 標準偏差が閾値以下なら採用
    else:
        return []

def extend_line(line, shape):
    """
    直線を画像の範囲外に延長する関数。
    """
    x1, y1, x2, y2 = line
    height, width = shape[:2]
    
    # 直線の傾きと切片を計算
    if x2 != x1:
        slope = (y2 - y1) / (x2 - x1)
        intercept = y1 - slope * x1
        x_start = 0
        y_start = int(intercept)
        x_end = width
        y_end = int(slope * width + intercept)
    else:
        # 垂直線の場合
        x_start = x_end = x1
        y_start = 0
        y_end = height

    return [x_start, y_start, x_end, y_end]


def calculate_intersection(line1, line2):
    """
    消失点と基準オブジェクトを使用して縮尺を計算する関数。

    :param image_path: 画像のパス
    :param real_distance: 基準オブジェクトの実際の距離（メートル）
    :param reference_points: 基準オブジェクトの2つの点の座標 [(x1, y1), (x2, y2)]
    :return: 画像内のピクセルあたりの実際の距離（メートル/ピクセル）
    """

    x1, y1, x2, y2 = map(float, line1)
    x3, y3, x4, y4 = map(float, line2)

    denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if denom == 0:
        return None

    px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / denom
    py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / denom

    return [px, py]

img = cv2.imread("test3.jpg")
img = find_vanishing_point(img)
cv2.line(img, (250, 98), (246, 614), (0, 255, 0), 2)
cv2.line(img, (431, 121), (421, 256), (0, 255, 0), 2)
cv2.namedWindow("img", cv2.WINDOW_NORMAL)
cv2.resizeWindow('img', 800, 600)
cv2.imshow('img', img)
cv2.waitKey(0)
cv2.destroyAllWindows()